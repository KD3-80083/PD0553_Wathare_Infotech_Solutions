// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const DataDisplay = () => {
//   const [data, setData] = useState([]);

//   useEffect(() => {
//     axios.get('http://localhost:3000/api/vibration-data')
//       .then(response => setData(response.data))
//       .catch(error => console.error(error));
//   }, []);

//   return (
//     <div>
//       {data.map(item => (
//         <div key={item.id} style={{ color: item.machine_status === 1 ? 'green' : 'red' }}>
//           Timestamp: {new Date(item.ts).toLocaleString()}, Vibration: {item.vibration}
//         </div>
//       ))}
//     </div>
//   );
// };

// export default DataDisplay;











// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const DataDisplay = () => {
//   const [data, setData] = useState([]);
//   const [timeScale, setTimeScale] = useState('1hr'); // Default time scale

//   useEffect(() => {
//     axios.get('http://localhost:3000/api/vibration-data')
//       .then(response => {
//         // Process data here if necessary
//         setData(response.data);
//       })
//       .catch(error => console.error(error));
//   }, []);

//   // Function to change the time scale
//   const changeTimeScale = (scale) => {
//     setTimeScale(scale);
//     // Implement the logic to filter data based on the selected time scale
//   };

//   return (
//     <div>
//       <div>
//         <button onClick={() => changeTimeScale('1hr')}>1hr</button>
//         <button onClick={() => changeTimeScale('8hr')}>8hr</button>
//         <button onClick={() => changeTimeScale('24hr')}>24hr</button>
//       </div>
//       <div style={{ display: 'flex', alignItems: 'center' }}>
//         {data.map(item => (
//           <div key={item.id} style={{
//             height: '20px',
//             width: '5px', // Adjust width based on total duration and scale
//             backgroundColor: item.vibration === 0 ? 'yellow' : item.vibration === 1 ? 'green' : 'red',
//           }} />
//         ))}
//       </div>
//       <div>
//         {/* Time markers can be dynamically generated based on data */}
//       </div>
//       {/* Additional UI components for summary and other considerations can be added here */}
//     </div>
//   );
// };

// export default DataDisplay;


import React, { useState, useEffect } from 'react';
import axios from 'axios';

const DataDisplay = () => {
  const [data, setData] = useState([]);
  const [timeScale, setTimeScale] = useState('1hr'); // Default time scale

  useEffect(() => {
    axios.get('http://localhost:3000/api/vibration-data')
      .then(response => {
        // Process data here if necessary
        setData(response.data);
      })
      .catch(error => console.error(error));
  }, []);

  // Function to change the time scale
  const changeTimeScale = (scale) => {
    setTimeScale(scale);
    // Implement the logic to filter data based on the selected time scale
  };

  return (
    <div>
      <div>
        <button onClick={() => changeTimeScale('1hr')}>1hr</button>
        <button onClick={() => changeTimeScale('8hr')}>8hr</button>
        <button onClick={() => changeTimeScale('24hr')}>24hr</button>
      </div>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        {data.map(item => (
          <div key={item.id} style={{
            height: '20px',
            width: getTimeScaleWidth(item.ts, timeScale), // Adjust width based on total duration and scale
            backgroundColor: getStatusColor(item.vibration),
          }} />
        ))}
      </div>
      <div>
        {/* Time markers can be dynamically generated based on data */}
        {generateTimeMarkers(timeScale)}
      </div>
      {/* Additional UI components for summary and other considerations can be added here */}
    </div>
  );
};

// Function to calculate the width based on the time scale
const getTimeScaleWidth = (timestamp, scale) => {
  // Logic to calculate width based on timestamp and scale
  return '5px'; // Placeholder width
};

// Function to generate time markers based on the selected time scale
const generateTimeMarkers = (scale) => {
  // Logic to generate time markers
  return <div>Time markers</div>; // Placeholder for time markers
};

// Function to get status color based on the vibration value
const getStatusColor = (vibration) => {
  if (vibration === 0) {
    return 'yellow';
  } else if (vibration === 1) {
    return 'green';
  } else {
    return 'red';
  }
};

export default DataDisplay;