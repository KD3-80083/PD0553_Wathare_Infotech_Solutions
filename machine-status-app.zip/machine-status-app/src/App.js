import React from 'react';
import DataDisplay from './DataDisplay';

function App() {
  return (
    <div className="App">
      <DataDisplay />
    </div>
  );
}

export default App;