// Import required modules
const express = require('express');
const mysql = require('mysql2');
const router = express.Router();
const path = require('path');

// Database Connection
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'manager',
  database: 'machine_data'
});

// Load JSON data
const jsonFilePath = path.resolve(__dirname, 'C:\\Users\\prash\\Desktop\\sample-data.json');
const jsonData = require(jsonFilePath);

// Convert ISO 8601 timestamp to MySQL datetime format
jsonData.forEach(obj => {
    obj.ts = new Date(obj.ts).toISOString().slice(0, 19).replace('T', ' ');
});

// Insert Data into MySQL Table
// const insertQuery = 'INSERT INTO vibration_data (ts, machine_status, vibration) VALUES ?';
// db.query(insertQuery, [jsonData.map(obj => [obj.ts, obj.machine_status, obj.vibration])], (err, result) => {
//     if (err) {
//         console.error('Error inserting data:', err);
//         return;
//     }
//     console.log('Data inserted successfully!');
// });

// API endPoint to Get Data
router.get('/vibration-data', (req, res) => {
  db.query('SELECT * FROM vibration_data', (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

module.exports = router;
